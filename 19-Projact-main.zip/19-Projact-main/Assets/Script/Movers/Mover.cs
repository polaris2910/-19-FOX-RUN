using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class Mover : BaseMover
{
    protected override void Update()
    {
        base.Update();
    }

}



